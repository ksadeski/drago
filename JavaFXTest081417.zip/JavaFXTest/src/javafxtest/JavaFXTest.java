/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javafxtest;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.Button;
import javafx.scene.image.ImageView;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author ksadeski
 */

//https://github.com/tutsplus/Introduction-to-JavaFX-for-Game-Development
//https://gamedevelopment.tutsplus.com/tutorials/introduction-to-javafx-for-game-development--cms-23835

public class JavaFXTest extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        Canvas canvas = new Canvas( 500, 500 );
        Group group = new Group();
        group.getChildren().add(canvas);
        
        Dragon dragon = new Dragon();

        Scene scene = new Scene(group, 300, 250);
                
        Listeners listeners = new Listeners(scene);
        listeners.addListeners();
        
        Button btn = new Button();
        btn.setText("Move dragon!");
        btn.setOnAction(new EventHandler<ActionEvent>() {
 
            @Override
            public void handle(ActionEvent event) {
                dragon.move();
            }
        });
        
        group.getChildren().add(btn);
        group.getChildren().add(dragon.getImageView());
        
        primaryStage.setScene(scene);
        scene.getStylesheets().add(JavaFXTest.class.getResource("main.css").toExternalForm());
        
        primaryStage.setTitle("rrrrrr");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
