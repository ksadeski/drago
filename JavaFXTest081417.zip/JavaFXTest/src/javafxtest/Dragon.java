package javafxtest;
import javafx.scene.image.Image; 
import javafx.scene.image.ImageView; 

/**
 *
 * @author ksadeski
 */

public class Dragon {
    int x, y, dx, dy; 
    ImageView ivDragon; 
    Dragon(){ 
        x=10; 
        y=15; 
        dx=10; 
        dy=10; 
        Image imgDragon = new Image(getClass().getResourceAsStream("drago.png")); 
        ivDragon = new ImageView(imgDragon); 
        ivDragon.setLayoutX(x); 
        ivDragon.setLayoutY(y); 
    } 
    public ImageView getImageView(){ 
        return ivDragon; 
    }
    
    public void move() {
        ivDragon.setLayoutX(Math.random()*100);
        ivDragon.setLayoutY(Math.random()*100);
    }
} 
